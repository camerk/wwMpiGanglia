#define CONFIG_PS 1
