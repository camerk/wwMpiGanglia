#define CONFIG_DEFAULT_MODULES_DIR "/lib/modules"
