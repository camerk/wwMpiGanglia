#define CONFIG_LESS 1
